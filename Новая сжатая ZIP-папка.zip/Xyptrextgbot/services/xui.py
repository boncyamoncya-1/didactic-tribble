from __future__ import annotations

import json
import time
import uuid
from typing import Any
from urllib.parse import urljoin

import httpx


class XUIError(RuntimeError):
    """Readable error returned by the 3x-ui API client."""


class XUIPanel:
    """3x-ui API client: prefer Bearer API token, fall back to API login if configured."""

    def __init__(
        self, *, name: str, base_url: str, username: str = "", password: str = "",
        api_token: str = "", verify_ssl: bool = True, timeout: float = 20.0,
    ) -> None:
        self.name = name
        self.base_url = base_url.strip().rstrip("/") + "/"
        self.username = username.strip()
        self.password = password
        self.api_token = api_token.strip()
        self.verify_ssl = verify_ssl
        self.timeout = timeout
        if not self.base_url.startswith(("http://", "https://")):
            raise XUIError("base_url должен начинаться с http:// или https://")

    def _url(self, path: str) -> str:
        # base_url must be the panel root, including webBasePath if one is configured.
        return urljoin(self.base_url, path.lstrip("/"))

    async def _new_client(self, *, bearer: bool) -> httpx.AsyncClient:
        client = httpx.AsyncClient(
            verify=self.verify_ssl,
            timeout=self.timeout,
            follow_redirects=True,
            headers={"Accept": "application/json", "User-Agent": "XyptrexVPNBot/1.0"},
        )
        if bearer and self.api_token:
            client.headers["Authorization"] = f"Bearer {self.api_token}"
        elif self.username and self.password:
            try:
                response = await client.post(
                    self._url("login"),
                    data={"username": self.username, "password": self.password},
                )
                if response.status_code in (401, 403):
                    raise XUIError(
                        f"{self.name}: вход по username/password отклонён (HTTP {response.status_code}). "
                        "Проверь логин, пароль и webBasePath панели."
                    )
                response.raise_for_status()
                try:
                    payload = response.json()
                except ValueError:
                    payload = {}
                if isinstance(payload, dict) and payload.get("success") is False:
                    raise XUIError(
                        f"{self.name}: панель отклонила вход: "
                        f"{payload.get('msg') or payload.get('message') or 'неизвестная ошибка'}"
                    )
            except XUIError:
                await client.aclose()
                raise
            except httpx.HTTPStatusError as exc:
                await client.aclose()
                raise XUIError(
                    f"{self.name}: endpoint авторизации вернул HTTP {exc.response.status_code}. "
                    "Проверь адрес панели и webBasePath."
                ) from exc
            except httpx.HTTPError as exc:
                await client.aclose()
                raise XUIError(f"{self.name}: не удалось обратиться к endpoint авторизации: {exc}") from exc
        else:
            await client.aclose()
            raise XUIError(
                f"{self.name}: не настроена авторизация. Нужен API-токен или username/password."
            )
        return client

    async def _request_with_client(self, client: httpx.AsyncClient, method: str, path: str,
                                   data: Any = None, json_body: Any = None) -> Any:
        request_kwargs = {"data": data} if json_body is None else {"json": json_body}
        response = await client.request(method, self._url(path), **request_kwargs)
        if response.status_code in (401, 403):
            raise _AuthRejected(response.status_code)
        try:
            response.raise_for_status()
        except httpx.HTTPStatusError as exc:
            body = (exc.response.text or "").strip().replace("\n", " ")[:240]
            if exc.response.status_code == 404:
                raise XUIError(
                    f"{self.name}: HTTP 404 на {path} (URL: {self._url(path)}). "
                    f"Ответ сервера: {body or 'пусто'}. Проверь base_url, webBasePath и наличие endpoint в версии 3x-ui."
                ) from exc
            raise XUIError(
                f"{self.name}: API вернул HTTP {exc.response.status_code} на {path}. {body}"
            ) from exc
        try:
            payload = response.json()
        except ValueError as exc:
            body = (response.text or "").strip().replace("\n", " ")[:160]
            raise XUIError(
                f"{self.name}: вместо JSON получен другой ответ на {path}. "
                f"Возможно, указан URL веб-страницы, а не API. Ответ: {body}"
            ) from exc
        if isinstance(payload, dict) and payload.get("success") is False:
            raise XUIError(
                f"{self.name}: ошибка API на {path}: "
                f"{payload.get('msg') or payload.get('message') or 'операция отклонена'}"
            )
        return payload

    async def _request(self, method: str, path: str, *, data: Any = None, json_body: Any = None) -> Any:
        # First try the programmatic API token. On auth rejection, automatically try
        # the standard 3x-ui session login if credentials were also configured.
        if self.api_token:
            client = await self._new_client(bearer=True)
            try:
                try:
                    return await self._request_with_client(client, method, path, data, json_body)
                except _AuthRejected as exc:
                    if not (self.username and self.password):
                        raise XUIError(
                            f"{self.name}: API-токен отклонён (HTTP {exc.status}). "
                            "Создай/проверь токен в настройках 3x-ui → Security → API Token."
                        ) from exc
            except httpx.HTTPError as exc:
                raise XUIError(f"{self.name}: ошибка HTTP-запроса: {exc}") from exc
            finally:
                await client.aclose()

        # Session-based API auth is also automatic and requires no browser interaction.
        client = await self._new_client(bearer=False)
        try:
            try:
                return await self._request_with_client(client, method, path, data, json_body)
            except _AuthRejected as exc:
                raise XUIError(
                    f"{self.name}: API отклонил авторизацию (HTTP {exc.status}) даже после входа. "
                    "Проверь credentials, webBasePath и поддержку CSRF/API в установленной версии. "
                    "Предпочтительно использовать API-токен Bearer."
                ) from exc
            except httpx.HTTPError as exc:
                raise XUIError(f"{self.name}: ошибка HTTP-запроса: {exc}") from exc
        finally:
            await client.aclose()

    async def list_inbounds(self) -> list[dict[str, Any]]:
        payload = await self._request("GET", "panel/api/inbounds/list")
        items = payload.get("obj", payload.get("data")) if isinstance(payload, dict) else None
        if not isinstance(items, list):
            raise XUIError(f"{self.name}: API не вернул список inbound в поле obj/data.")
        return [item for item in items if isinstance(item, dict)]

    async def test_connection(self) -> str:
        inbounds = await self.list_inbounds()
        return f"Соединение успешно. Найдено inbound: {len(inbounds)}"

    async def list_clients(self) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for inbound in await self.list_inbounds():
            settings = inbound.get("settings", {})
            if isinstance(settings, str):
                try:
                    settings = json.loads(settings)
                except json.JSONDecodeError:
                    settings = {}
            clients = settings.get("clients", []) if isinstance(settings, dict) else []
            for client in clients if isinstance(clients, list) else []:
                if isinstance(client, dict):
                    item = dict(client)
                    item["_inbound_id"] = inbound.get("id")
                    item["_inbound_remark"] = inbound.get("remark", "")
                    item["_protocol"] = inbound.get("protocol", "")
                    result.append(item)
        return result

    async def add_client(
        self, inbound_id: int, *, email: str, total_gb: int, duration_days: int,
        max_ips: int = 1, flow: str = "", client_uuid: str | None = None, sub_id: str | None = None,
        client_label: str = "",
    ) -> dict[str, Any]:
        # Shared UUID and subId allow the same logical subscription to span multiple inbounds.
        client_uuid = str(client_uuid or uuid.uuid4())
        sub_id = str(sub_id or uuid.uuid4().hex[:16])
        expiry_ms = int(time.time() * 1000) + int(duration_days) * 86400 * 1000
        total_bytes = max(0, int(total_gb)) * 1024**3
        client = {
            "id": client_uuid,
            "email": email,
            "enable": True,
            "limitIp": max(0, int(max_ips)),
            "totalGB": total_bytes,
            "expiryTime": expiry_ms,
            "flow": flow,
            "subId": sub_id,
            "comment": (client_label or "Created by Xyptrex VPN Bot")[:255],
            "reset": 0,
        }
        # Legacy 3x-ui API: form-urlencoded id + JSON-encoded settings.
        payload = {"id": int(inbound_id), "settings": json.dumps({"clients": [client]})}
        try:
            response = await self._request("POST", "panel/api/inbounds/addClient", data=payload)
            return {"client": client, "response": response, "api": "legacy-inbounds"}
        except XUIError as legacy_error:
            if "HTTP 404" not in str(legacy_error):
                raise
            # A few reverse proxies/forks register the same route with a trailing slash.
            try:
                response = await self._request("POST", "panel/api/inbounds/addClient/", data=payload)
                return {"client": client, "response": response, "api": "legacy-inbounds-slash"}
            except XUIError as slash_error:
                if "HTTP 404" not in str(slash_error):
                    raise
                legacy_error = slash_error
        # Newer 3x-ui releases expose client creation through the first-class Clients API.
        # This is still direct API communication; no browser or manual login is involved.
        modern_client = dict(client)
        modern_client["tgId"] = 0
        modern_payload = {"client": modern_client, "inboundIds": [int(inbound_id)]}
        try:
            response = await self._request("POST", "panel/api/clients/add", json_body=modern_payload)
            # Some newer builds generate/normalise the protocol identifier server-side; read it back.
            try:
                actual = next((item for item in await self.list_clients()
                               if str(item.get("_inbound_id")) == str(inbound_id)
                               and str(item.get("email", "")) == email), None)
                if actual:
                    client = {key: value for key, value in actual.items() if not key.startswith("_")}
            except XUIError:
                pass
            return {"client": client, "response": response, "api": "modern-clients"}
        except XUIError as modern_error:
            if "HTTP 404" in str(modern_error):
                raise XUIError(
                    f"{self.name}: API чтения inbound доступен, но endpoints создания клиента не найдены. "
                    f"Проверены panel/api/inbounds/addClient и panel/api/clients/add. "
                    "Вероятно, у вашей сборки другой API-маршрут или настроен отдельный webBasePath. "
                    f"Последняя ошибка: {modern_error}"
                ) from modern_error
            raise


    async def add_mtproto_client(self, inbound_id: int, *, email: str, client_label: str = "") -> dict[str, Any]:
        """Create one personal MTProto client and return the secret persisted by 3x-ui."""
        inbounds = await self.list_inbounds()
        inbound = next((item for item in inbounds if int(item.get("id") or 0) == int(inbound_id)), None)
        if not inbound:
            raise XUIError(f"{self.name}: MTProto inbound #{inbound_id} не найден.")
        if str(inbound.get("protocol", "")).lower() != "mtproto":
            raise XUIError(f"{self.name}: inbound #{inbound_id} не является MTProto.")
        settings = inbound.get("settings", {})
        if isinstance(settings, str):
            try:
                settings = json.loads(settings)
            except json.JSONDecodeError:
                settings = {}
        if not isinstance(settings, dict):
            settings = {}
        domain = str(settings.get("fakeTlsDomain") or "www.cloudflare.com").strip()
        # 3x-ui FakeTLS secret format: ee + 16 random bytes + hex-encoded SNI domain.
        secret = "ee" + uuid.uuid4().hex + domain.encode("utf-8").hex()
        client = {
            "email": email,
            "secret": secret,
            "tgId": 0,
            "enable": True,
            "limitIp": 0,
            "totalGB": 0,
            "expiryTime": 0,
            "subId": uuid.uuid4().hex[:16],
            "comment": (client_label or "Xyptrex Telegram Proxy")[:255],
            "reset": 0,
            "adTag": "",
        }
        modern_payload = {"client": client, "inboundIds": [int(inbound_id)]}
        try:
            await self._request("POST", "panel/api/clients/add", json_body=modern_payload)
        except XUIError as modern_error:
            if "HTTP 404" not in str(modern_error):
                raise
            # Compatibility path for builds exposing only the legacy inbound API.
            legacy_payload = {"id": int(inbound_id), "settings": json.dumps({"clients": [client]})}
            await self._request("POST", "panel/api/inbounds/addClient", data=legacy_payload)
        # Read the saved client back: the panel may normalize/regenerate FakeTLS secrets.
        saved_inbounds = await self.list_inbounds()
        saved_inbound = next((item for item in saved_inbounds if int(item.get("id") or 0) == int(inbound_id)), None)
        if not saved_inbound:
            raise XUIError(f"{self.name}: клиент создан, но inbound не удалось перечитать.")
        saved_settings = saved_inbound.get("settings", {})
        if isinstance(saved_settings, str):
            try:
                saved_settings = json.loads(saved_settings)
            except json.JSONDecodeError:
                saved_settings = {}
        clients = saved_settings.get("clients", []) if isinstance(saved_settings, dict) else []
        saved = next((cl for cl in clients if isinstance(cl, dict) and str(cl.get("email", "")) == email), None)
        if not saved or not str(saved.get("secret", "")).strip():
            raise XUIError(f"{self.name}: API не вернул сохранённый MTProto secret для клиента {email}.")
        return {"client": saved, "inbound": saved_inbound}

    async def delete_client(self, inbound_id: int, client_uuid: str, email: str = "", *, whole_client: bool = False) -> Any:
        # Classic API identifies VLESS/VMess clients by UUID.
        try:
            return await self._request("POST", f"panel/api/inbounds/{int(inbound_id)}/delClient/{client_uuid}", data={})
        except XUIError as legacy_error:
            if "HTTP 404" not in str(legacy_error) or not email:
                raise
            from urllib.parse import quote
            encoded_email = quote(email, safe="")
            if whole_client:
                # Delete the first-class client record only when it has no other local server entries.
                return await self._request("POST", f"panel/api/clients/del/{encoded_email}", json_body={})
            # Otherwise detach only from this inbound, preserving the client's other server attachments.
            return await self._request("POST", f"panel/api/clients/{encoded_email}/detach", json_body={"inboundIds": [int(inbound_id)]})

    async def update_client(self, inbound_id: int, client_uuid: str, client: dict[str, Any]) -> Any:
        clean = {key: value for key, value in client.items() if not key.startswith("_")}
        payload = {"id": int(inbound_id), "settings": json.dumps({"clients": [clean]})}
        return await self._request("POST", f"panel/api/inbounds/updateClient/{client_uuid}", data=payload)

    async def reset_client_traffic(self, inbound_id: int, email: str) -> Any:
        return await self._request(
            "POST", f"panel/api/inbounds/{int(inbound_id)}/resetClientTraffic/{email}", data={}
        )

    async def extend_client(self, inbound_id: int, client_uuid: str, days: int) -> dict[str, Any]:
        clients = await self.list_clients()
        target = next((client for client in clients
                       if str(client.get("_inbound_id")) == str(inbound_id)
                       and str(client.get("id")) == str(client_uuid)), None)
        if target is None:
            raise XUIError("Клиент не найден в выбранном inbound.")
        current_ms = int(target.get("expiryTime") or 0)
        target["expiryTime"] = max(current_ms, int(time.time() * 1000)) + max(1, int(days)) * 86400 * 1000
        clean = {key: value for key, value in target.items() if not key.startswith("_")}
        result = await self.update_client(inbound_id, client_uuid, clean)
        return {"client": clean, "response": result}


class _AuthRejected(Exception):
    def __init__(self, status: int) -> None:
        self.status = status
        super().__init__(f"Authentication rejected: HTTP {status}")
