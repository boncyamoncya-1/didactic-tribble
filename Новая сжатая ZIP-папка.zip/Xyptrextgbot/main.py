from __future__ import annotations

import argparse
import asyncio
import json
import logging
import io
import uuid
import re
import time
from urllib.parse import urlparse, urlencode
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import aiosqlite
import yaml
from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message, BufferedInputFile

from services.xui import XUIError, XUIPanel

BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = BASE_DIR / "config.yml"
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("xyptrex")


def load_config(*, require_bot: bool = True) -> dict[str, Any]:
    if not CONFIG_PATH.exists():
        raise FileNotFoundError("Не найден config.yml. Создайте его из config.example.yml.")
    cfg = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8")) or {}
    token = str(cfg.get("bot", {}).get("token", "")).strip()
    if require_bot and (not token or token == "PASTE_TELEGRAM_BOT_TOKEN_HERE"):
        raise ValueError("Укажите токен Telegram-бота в config.yml.")
    ids = cfg.get("admin", {}).get("ids", [])
    if not isinstance(ids, list) or not ids:
        raise ValueError("Укажите Telegram ID администраторов в admin.ids.")
    cfg["admin"]["ids"] = [int(x) for x in ids]
    cfg.setdefault("database", {}).setdefault("path", "database/bot.db")
    cfg.setdefault("panels", [])
    return cfg


def dbfile(cfg: dict[str, Any]) -> Path:
    p = Path(cfg["database"]["path"])
    return p if p.is_absolute() else BASE_DIR / p


def admin(cfg: dict[str, Any], uid: int) -> bool:
    return uid in cfg["admin"]["ids"]


def panel_cfg(cfg: dict[str, Any], pid: str) -> dict[str, Any] | None:
    return next((p for p in cfg.get("panels", []) if str(p.get("id")) == pid), None)


def panel_obj(p: dict[str, Any]) -> XUIPanel:
    return XUIPanel(name=str(p.get("name", p.get("id", "3x-ui"))),
        base_url=str(p["base_url"]), username=str(p.get("username", "")),
        password=str(p.get("password", "")), api_token=str(p.get("api_token", "")),
        verify_ssl=bool(p.get("verify_ssl", True)))


async def init_db(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(path) as db:
        await db.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(
            telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tariffs(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, duration_days INTEGER NOT NULL,
            price INTEGER NOT NULL DEFAULT 0, device_limit INTEGER NOT NULL DEFAULT 1,
            traffic_gb INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1,
            server_targets TEXT NOT NULL DEFAULT '[]'
        );
        CREATE TABLE IF NOT EXISTS subscription_requests(
            id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL,
            tariff_id INTEGER, tariff_name TEXT NOT NULL, duration_days INTEGER NOT NULL,
            price INTEGER NOT NULL, device_limit INTEGER NOT NULL DEFAULT 1,
            traffic_gb INTEGER NOT NULL DEFAULT 0, server_targets TEXT NOT NULL DEFAULT '[]', email TEXT NOT NULL DEFAULT '',
            telegram_username TEXT NOT NULL DEFAULT '', subscription_no INTEGER, status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_by INTEGER, reviewed_at TEXT
        );
        CREATE TABLE IF NOT EXISTS subscriptions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER,
            panel_id TEXT NOT NULL, inbound_id INTEGER, client_uuid TEXT, email TEXT,
            client_json TEXT, sub_url TEXT, tariff_name TEXT, start_at INTEGER,
            expiry_at INTEGER, device_limit INTEGER DEFAULT 1, traffic_gb INTEGER DEFAULT 0,
            subscription_no INTEGER, subscription_group TEXT, sub_id TEXT,
            status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(panel_id, inbound_id, client_uuid)
        );
        CREATE TABLE IF NOT EXISTS telegram_proxies(
            telegram_id INTEGER PRIMARY KEY, panel_id TEXT NOT NULL, inbound_id INTEGER NOT NULL,
            client_email TEXT NOT NULL, secret TEXT NOT NULL, link TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'active', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        """)
        # Upgrade databases created by earlier bot builds without deleting existing rows.
        for table, column, definition in (
            ("tariffs", "server_targets", "TEXT NOT NULL DEFAULT '[]'"),
            ("subscription_requests", "server_targets", "TEXT NOT NULL DEFAULT '[]'"),
            ("subscription_requests", "email", "TEXT NOT NULL DEFAULT ''"),
            ("subscription_requests", "telegram_username", "TEXT NOT NULL DEFAULT ''"),
            ("subscription_requests", "subscription_no", "INTEGER"),
            ("subscriptions", "subscription_no", "INTEGER"),
            ("subscriptions", "subscription_group", "TEXT"),
            ("subscriptions", "sub_id", "TEXT"),
        ):
            cur = await db.execute(f"PRAGMA table_info({table})")
            columns = {row[1] for row in await cur.fetchall()}
            if column not in columns:
                await db.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
        defaults = {
            "welcome": "Добро пожаловать в Xyptrex VPN!\n\nВыберите действие в меню ниже.",
            "support": "@xyptrex_support",
            "service_name": "Xyptrex VPN",
            "default_subscription_url": "https://xyptrex.ru:80/subscribtion/",
            "default_inbound_id": "",
            "default_panel_id": "main",
            "tgproxy_enabled": "1",
            "tgproxy_panel_id": "",
            "tgproxy_inbound_id": "",
            "tgproxy_host": "",
        }
        for key, value in defaults.items():
            await db.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))
        # Migrate the previous default URL in existing installations as well.
        await db.execute(
            "UPDATE settings SET value='https://xyptrex.ru:80/subscribtion/' "
            "WHERE key='default_subscription_url' AND value IN "
            "('https://xyptrex.ru/subscribtion', 'https://xyptrex.ru/subscribtion/')"
        )
        # Update already-issued links that used the old host without :80.
        await db.execute(
            "UPDATE subscriptions SET sub_url=REPLACE(sub_url, "
            "'https://xyptrex.ru/subscribtion', 'https://xyptrex.ru:80/subscribtion') "
            "WHERE sub_url LIKE 'https://xyptrex.ru/subscribtion%'"
        )
        cur = await db.execute("SELECT COUNT(*) FROM tariffs")
        if (await cur.fetchone())[0] == 0:
            await db.executemany(
                "INSERT INTO tariffs(name,duration_days,price,device_limit,traffic_gb) VALUES(?,?,?,?,?)",
                [("1 месяц", 30, 0, 1, 0), ("3 месяца", 90, 0, 1, 0), ("1 год", 365, 0, 1, 0)]
            )
        await db.commit()


async def setting(path: Path, key: str, default: str = "") -> str:
    async with aiosqlite.connect(path) as db:
        cur = await db.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = await cur.fetchone()
        return str(row[0]) if row else default


async def set_setting(path: Path, key: str, value: str) -> None:
    async with aiosqlite.connect(path) as db:
        await db.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
        await db.commit()


async def save_user(path: Path, user) -> None:
    async with aiosqlite.connect(path) as db:
        await db.execute("""INSERT INTO users(telegram_id,username,first_name) VALUES(?,?,?)
        ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name""",
        (user.id, user.username, user.first_name))
        await db.commit()


def ik(rows: list[list[tuple[str, str]]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=label, callback_data=data) for label, data in row] for row in rows
    ])


def user_menu() -> InlineKeyboardMarkup:
    return ik([[("🛒 Купить подписку", "u:buy")], [("📦 Мои подписки", "u:subs")],
               [("🔐 Telegram Proxy", "u:tgproxy")],
               [("🔄 Управление подпиской", "u:manage")], [("🛟 Поддержка", "u:support")]])

def admin_menu() -> InlineKeyboardMarkup:
    return ik([[("📥 Запросы на подписку", "a:requests")], [("📦 Подписки / клиенты", "a:subs")],
        [("🧑‍💻 Управление своей подпиской", "a:own")], [("📡 Telegram Proxy", "a:tgproxy")], [("🖥 Серверы 3x-ui", "a:panels")],
        [("➕ Создать пользователя", "a:create")], [("💳 Тарифы", "a:tariffs")],
        [("⚙️ Настройки / приветствие", "a:settings")], [("📊 Статистика", "a:stats")],
        [("👤 Пользовательское меню", "u:home")]])


async def home(message: Message, cfg: dict[str, Any], path: Path, uid: int | None = None):
    user = message.from_user
    uid = uid or user.id
    await save_user(path, user)
    if admin(cfg, uid):
        await message.answer("🔐 Панель администратора\n\nВыберите раздел:", reply_markup=admin_menu())
    else:
        welcome = await setting(path, "welcome", "Добро пожаловать в Xyptrex VPN!")
        await message.answer(welcome, reply_markup=user_menu())


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check-config", action="store_true")
    parser.add_argument("--test-panels", action="store_true", help="Проверить соединение с API всех включённых панелей")
    args = parser.parse_args()
    cfg = load_config(require_bot=not args.test_panels)
    if args.check_config:
        print("Конфигурация корректна.")
        return
    if args.test_panels:
        panels = [p for p in cfg.get("panels", []) if p.get("enabled") is True]
        if not panels:
            print("Нет включённых панелей. В config.yml установите panels[].enabled: true.")
            return
        for panel in panels:
            name = str(panel.get("name", panel.get("id", "3x-ui")))
            try:
                if not panel.get("base_url"):
                    raise XUIError("Не задан base_url.")
                result = await panel_obj(panel).test_connection()
                clients = await panel_obj(panel).list_clients()
                print(f"[OK] {name}: {result}; клиентов: {len(clients)}")
            except (XUIError, KeyError, ValueError) as exc:
                print(f"[ERROR] {name}: {exc}")
        return
    path = dbfile(cfg)
    await init_db(path)
    bot = Bot(cfg["bot"]["token"])
    dp = Dispatcher()

    def subscription_url(base: str, sub_id: str) -> str:
        base = (base or "").strip()
        if not base:
            raise XUIError("Не настроен default_subscription_url в базе. Укажите URL подписки в настройках.")
        if "{sub_id}" in base:
            return base.replace("{sub_id}", sub_id)
        return base.rstrip("/") + "/" + sub_id

    async def next_subscription_number(telegram_id: int) -> int:
        async with aiosqlite.connect(path) as db:
            cur = await db.execute(
                "SELECT subscription_no FROM subscriptions WHERE telegram_id=? AND status='active' AND subscription_no IS NOT NULL UNION SELECT subscription_no FROM subscription_requests WHERE telegram_id=? AND status='pending' AND subscription_no IS NOT NULL",
                (telegram_id, telegram_id),
            )
            used = {int(row[0]) for row in await cur.fetchall() if row[0] is not None}
        number = 1
        while number in used:
            number += 1
        return number

    def make_panel_client_email(telegram_id: int, number: int) -> str:
        # 3x-ui validates the client email field as a restricted identifier, not as
        # a display name. Keep it ASCII-safe and unique; human-readable metadata
        # is stored separately in the client's comment.
        return f"tg{int(telegram_id)}_s{int(number)}"

    async def deliver_subscription(telegram_id: int, email: str, number: int, sub_url: str, tariff_name: str, days: int, expiry: int) -> None:
        expiry_text = datetime.fromtimestamp(expiry, timezone.utc).strftime("%d.%m.%Y %H:%M UTC") if expiry else "не указан"
        text = (
            f"✅ Ваша подписка одобрена!\n\n"
            f"Ваша VLESS-ссылка доступа ко всем серверам:\n{sub_url}\n\n"
            f"Подписка №{number} · {tariff_name}\nСрок: {days} дней\nДействует до: {expiry_text}\n\n"
            "Добавьте ссылку в VPN-клиент. QR-код ниже можно отсканировать в приложении."
        )
        try:
            import qrcode
            image = qrcode.make(sub_url)
            buffer = io.BytesIO()
            image.save(buffer, format="PNG")
            await bot.send_photo(telegram_id, BufferedInputFile(buffer.getvalue(), filename=f"xyptrex-sub-{number}.png"), caption=f"QR-код вашей VPN-подписки №{number}")
        except Exception as exc:
            log.warning("QR не отправлен, отправляю ссылку текстом: %s", exc)
        await bot.send_message(telegram_id, text)

    async def provision_request(rid: int, reviewed_by: int | None = None) -> dict[str, Any]:
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("SELECT telegram_id,tariff_name,duration_days,price,device_limit,traffic_gb,status,server_targets,email,telegram_username,subscription_no FROM subscription_requests WHERE id=?", (rid,))
            req = await cur.fetchone()
        if not req:
            raise XUIError("Заявка не найдена.")
        tg_id, tariff_name, days, price, devices, traffic, status, raw_targets, user_email, tg_username, sub_no = req
        if status != "pending":
            raise XUIError("Заявка уже обработана.")
        targets = json.loads(raw_targets or "[]")
        if not targets:
            raise XUIError("У тарифа не выбраны серверы/inbound.")
        number = int(sub_no or await next_subscription_number(int(tg_id)))
        username = str(tg_username or "").strip()
        username = "@" + username.lstrip("@") if username else f"tg{tg_id}"
        # This is an internal API identifier only. Never expose it as the user's
        # subscription name; 3x-ui rejects spaces/@ in its email identifier.
        client_email = make_panel_client_email(int(tg_id), number)
        client_label = f"{user_email} - tg - {username} - {number}"
        group_id = uuid.uuid4().hex
        client_uuid = str(uuid.uuid4())
        sub_id = uuid.uuid4().hex[:16]
        sub_url = subscription_url(await setting(path, "default_subscription_url", "https://xyptrex.ru:80/subscribtion/"), sub_id)
        now = int(time.time())
        created: list[tuple[str, int, dict[str, Any], str]] = []
        db_committed = False
        try:
            for target in targets:
                pid, inbound_id = str(target["panel_id"]), int(target["inbound_id"])
                panel = panel_cfg(cfg, pid)
                if not panel or not panel.get("enabled"):
                    raise XUIError(f"Сервер {pid} выключен или отсутствует в config.yml.")
                result = await panel_obj(panel).add_client(
                    inbound_id, email=client_email, total_gb=int(traffic), duration_days=int(days),
                    max_ips=int(devices), client_uuid=client_uuid, sub_id=sub_id,
                    client_label=client_label,
                )
                created.append((pid, inbound_id, result["client"], client_email))
            expiry = now + int(days) * 86400
            async with aiosqlite.connect(path) as db:
                for pid, inbound_id, client, entry_email in created:
                    await db.execute("""INSERT INTO subscriptions
                        (telegram_id,panel_id,inbound_id,client_uuid,email,client_json,sub_url,tariff_name,start_at,expiry_at,device_limit,traffic_gb,subscription_no,subscription_group,sub_id,status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'active')""",
                        (tg_id, pid, inbound_id, client_uuid, entry_email, json.dumps(client), sub_url, tariff_name, now,
                         expiry, int(devices), int(traffic), number, group_id, sub_id))
                await db.execute("UPDATE subscription_requests SET status='approved',reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?", (reviewed_by, rid))
                await db.commit()
            db_committed = True
            try:
                await deliver_subscription(int(tg_id), str(user_email), number, sub_url, str(tariff_name), int(days), expiry)
            except Exception:
                # The subscription is already committed; notification failure must not roll back access.
                log.exception("Подписка создана, но не удалось отправить сообщение пользователю %s", tg_id)
            return {"servers": len(created), "number": number, "url": sub_url}
        except Exception:
            if db_committed:
                raise
            for rollback_pid, rollback_inbound, rollback_client, rollback_email in reversed(created):
                rollback_panel = panel_cfg(cfg, rollback_pid)
                if rollback_panel:
                    try:
                        await panel_obj(rollback_panel).delete_client(rollback_inbound, str(rollback_client.get("id", client_uuid)), rollback_email)
                    except Exception as rollback_error:
                        log.error("Rollback клиента %s не удался: %s", rollback_email, rollback_error)
            raise

    @dp.message(CommandStart())
    async def start(message: Message):
        await home(message, cfg, path)

    @dp.message(Command("admin"))
    async def admin_command(message: Message):
        if not admin(cfg, message.from_user.id):
            await message.answer("⛔ Нет доступа.")
            return
        await message.answer("🔐 Панель администратора", reply_markup=admin_menu())

    @dp.callback_query(F.data == "u:home")
    async def user_home(c: CallbackQuery):
        if admin(cfg, c.from_user.id):
            await c.message.edit_text("👤 Пользовательское меню", reply_markup=user_menu())
        else:
            await c.message.edit_text(await setting(path, "welcome"), reply_markup=user_menu())
        await c.answer()

    @dp.callback_query(F.data == "u:tgproxy")
    async def telegram_proxy_menu(c: CallbackQuery):
        enabled = await setting(path, "tgproxy_enabled", "1") == "1"
        pid = await setting(path, "tgproxy_panel_id", "")
        inbound_id = await setting(path, "tgproxy_inbound_id", "")
        if not enabled:
            await c.message.edit_text("Telegram Proxy временно отключён. Попробуйте позже.", reply_markup=ik([[ ("⬅️ Назад", "u:home")]]))
            await c.answer(); return
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("SELECT link,status FROM telegram_proxies WHERE telegram_id=?", (c.from_user.id,))
            existing = await cur.fetchone()
        if existing and existing[1] == "active":
            await c.message.edit_text("🔐 Ваш персональный Telegram Proxy уже создан. Ссылка закреплена за вашим аккаунтом:\n\n" + existing[0],
                reply_markup=ik([[ ("➕ Добавить прокси в Telegram", "u:tgproxy:open")], [ ("🔄 Проверить подключение", "u:tgproxy")], [ ("⬅️ Назад", "u:home")]]))
            await c.answer(); return
        if not pid or not inbound_id:
            await c.message.edit_text("Telegram Proxy пока не настроен. Обратитесь в поддержку.", reply_markup=ik([[ ("⬅️ Назад", "u:home")]]))
            await c.answer(); return
        await c.message.edit_text("Бесплатный персональный MTProto-прокси для Telegram. Для вас будет создан уникальный секрет.\n\nНажмите кнопку ниже, чтобы получить подключение.",
            reply_markup=ik([[ ("➕ Добавить прокси", "u:tgproxy:add")], [ ("⬅️ Назад", "u:home")]]))
        await c.answer()

    @dp.callback_query(F.data == "u:tgproxy:open")
    async def telegram_proxy_open(c: CallbackQuery):
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("SELECT link FROM telegram_proxies WHERE telegram_id=? AND status='active'", (c.from_user.id,))
            row = await cur.fetchone()
        if not row:
            await c.answer("Ссылка не найдена. Откройте раздел прокси снова.", show_alert=True); return
        await c.message.answer("Нажмите, чтобы открыть Telegram и добавить ваш персональный прокси:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Открыть Telegram Proxy", url=row[0])]]))
        await c.answer()

    @dp.callback_query(F.data == "u:tgproxy:add")
    async def telegram_proxy_create(c: CallbackQuery):
        await c.answer()
        if await setting(path, "tgproxy_enabled", "1") != "1":
            await c.message.answer("Telegram Proxy временно отключён. Обратитесь в поддержку."); return
        pid = await setting(path, "tgproxy_panel_id", "")
        inbound_id_raw = await setting(path, "tgproxy_inbound_id", "")
        if not pid or not inbound_id_raw:
            await c.message.answer("Telegram Proxy пока не настроен. Обратитесь в поддержку."); return
        try:
            inbound_id = int(inbound_id_raw)
            panel = panel_cfg(cfg, pid)
            if not panel or not panel.get("enabled"):
                raise XUIError("MTProto-панель отключена или не найдена.")
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT link,status FROM telegram_proxies WHERE telegram_id=?", (c.from_user.id,))
                existing = await cur.fetchone()
            if existing and existing[1] == "active":
                link = existing[0]
            else:
                email = f"tg{int(c.from_user.id)}_proxy"
                xui = panel_obj(panel)
                # If the request previously timed out after the panel created the client,
                # recover the saved secret instead of creating a duplicate.
                inbounds = await xui.list_inbounds()
                target = next((item for item in inbounds if int(item.get("id") or 0) == inbound_id), None)
                if not target or str(target.get("protocol", "")).lower() != "mtproto":
                    raise XUIError("Выбранный inbound не найден или не является MTProto.")
                settings_obj = target.get("settings", {})
                if isinstance(settings_obj, str):
                    settings_obj = json.loads(settings_obj or "{}")
                clients = settings_obj.get("clients", []) if isinstance(settings_obj, dict) else []
                client = next((cl for cl in clients if isinstance(cl, dict) and str(cl.get("email", "")) == email), None)
                if not client:
                    created = await xui.add_mtproto_client(inbound_id, email=email, client_label=f"Telegram proxy · TG {c.from_user.id}")
                    client = created["client"]
                secret = str(client.get("secret", "")).strip()
                if not secret:
                    raise XUIError("Панель не вернула персональный MTProto-секрет.")
                host = (await setting(path, "tgproxy_host", "")).strip()
                if not host:
                    host = str(target.get("shareAddr") or "").strip()
                if not host:
                    host = urlparse(str(panel.get("base_url", ""))).hostname or ""
                if not host or host in ("0.0.0.0", "127.0.0.1", "::"):
                    raise XUIError("Не задан публичный адрес MTProto-сервера. Администратор должен выполнить /tgproxyhost IP_ИЛИ_ДОМЕН.")
                link = "tg://proxy?" + urlencode({"server": host, "port": int(target.get("port") or 0), "secret": secret})
                async with aiosqlite.connect(path) as db:
                    await db.execute("""INSERT INTO telegram_proxies(telegram_id,panel_id,inbound_id,client_email,secret,link,status)
                        VALUES(?,?,?,?,?,?,'active') ON CONFLICT(telegram_id) DO UPDATE SET panel_id=excluded.panel_id,
                        inbound_id=excluded.inbound_id,client_email=excluded.client_email,secret=excluded.secret,link=excluded.link,status='active'""",
                        (c.from_user.id, pid, inbound_id, email, secret, link))
                    await db.commit()
            await c.message.answer("✅ Ваш персональный Telegram Proxy создан бесплатно.\n\nСсылка подключения:\n" + link,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="Открыть Telegram и добавить прокси", url=link)], [InlineKeyboardButton(text="⬅️ В меню", callback_data="u:home")]]))
        except Exception as exc:
            log.exception("MTProto выдача не удалась для Telegram ID %s", c.from_user.id)
            for aid in cfg["admin"]["ids"]:
                try: await bot.send_message(aid, f"Ошибка выдачи Telegram Proxy пользователю {c.from_user.id}: {exc}")
                except Exception: pass
            await c.message.answer("Не удалось создать прокси из-за технической ошибки. Администратор уведомлён; повторно оформлять запрос не нужно.", reply_markup=ik([[ ("⬅️ В меню", "u:home")]]))

    @dp.callback_query(F.data == "u:buy")
    async def buy(c: CallbackQuery):
        await set_setting(path, f"buy_pending:{c.from_user.id}", "")
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("SELECT id,name,duration_days,price,device_limit,traffic_gb FROM tariffs WHERE enabled=1 ORDER BY duration_days")
            tariffs = await cur.fetchall()
        rows = [[(f"{name} · {days} дн. · {price} ₽ · устройств: {devices}", f"u:tariff:{tid}")]
                for tid, name, days, price, devices, traffic in tariffs]
        rows.append([("⬅️ Назад", "u:home")])
        await c.message.edit_text("Выберите тариф:", reply_markup=ik(rows))
        await c.answer()

    @dp.callback_query(F.data.startswith("u:tariff:"))
    async def choose_tariff(c: CallbackQuery):
        tid = int(c.data.split(":")[2])
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("SELECT name,duration_days,price,device_limit,traffic_gb,server_targets FROM tariffs WHERE id=? AND enabled=1", (tid,))
            t = await cur.fetchone()
        if not t:
            await c.answer("Тариф больше недоступен.", show_alert=True); return
        name, days, price, devices, traffic, server_targets = t
        if not json.loads(server_targets or "[]"):
            await c.answer("У этого тарифа ещё не выбраны серверы. Обратитесь к администратору.", show_alert=True); return
        await save_user(path, c.from_user)
        await set_setting(path, f"buy_pending:{c.from_user.id}", str(tid))
        await c.message.edit_text(
            f"Тариф: {name}\nЦена: {price} ₽\nСрок: {days} дней\n\nВведите email, который будет использован как имя вашей VPN-подписки.\nНапример: asd@gmail.com\nДля отмены нажмите «Назад».",
            reply_markup=ik([[ ("⬅️ Назад", "u:buy") ]])
        )
        await c.answer()

    @dp.callback_query(F.data == "u:subs")
    async def my_subs(c: CallbackQuery):
        async with aiosqlite.connect(path) as db:
            cur = await db.execute("""SELECT id,panel_id,email,tariff_name,expiry_at,device_limit,traffic_gb,status,sub_url,subscription_no,subscription_group
                FROM subscriptions WHERE telegram_id=? ORDER BY id DESC""", (c.from_user.id,))
            rows = await cur.fetchall()
        if not rows:
            text = "Пока нет привязанных подписок. Если подписка уже есть в 3x-ui, попросите администратора привязать её к вашему Telegram."
        else:
            parts = []
            seen_groups = set()
            for sid, pid, email, tariff, expiry, devices, traffic, status, url, number, group in rows:
                group_key = group or f"legacy-{sid}"
                if group_key in seen_groups:
                    continue
                seen_groups.add(group_key)
                servers = sorted({str(row[1]) for row in rows if (row[10] or f"legacy-{row[0]}") == group_key})
                expiry_text = datetime.fromtimestamp(expiry, timezone.utc).strftime("%d.%m.%Y %H:%M UTC") if expiry else "не указан"
                label = f"Подписка №{number}" if number else f"Подписка #{sid}"
                parts.append(f"{label}\nСерверы: {', '.join(servers)}\nТариф: {tariff or 'не указан'}\nДо: {expiry_text}\nУстройств: {devices}\nЛимит трафика: {'без лимита' if not traffic else str(traffic)+' ГБ'}\nСтатус: {status}" + (f"\nVLESS-ссылка: {url}" if url else ""))
            text = "\n\n".join(parts)
        await c.message.edit_text(text, reply_markup=ik([[("⬅️ Назад", "u:home")]]))
        await c.answer()

    @dp.callback_query(F.data == "u:manage")
    async def manage(c: CallbackQuery):
        await c.message.edit_text("Управление доступно для привязанных подписок. Для продления выберите «Купить подписку» или обратитесь в поддержку.", reply_markup=ik([[("📦 Мои подписки", "u:subs")], [("🛒 Купить / продлить", "u:buy")], [("⬅️ Назад", "u:home")]]))
        await c.answer()

    @dp.callback_query(F.data == "u:support")
    async def support(c: CallbackQuery):
        contact = await setting(path, "support", "@xyptrex_support")
        await c.message.edit_text(f"🛟 Поддержка: {contact}", reply_markup=ik([[("⬅️ Назад", "u:home")]]))
        await c.answer()

    @dp.callback_query(F.data.startswith("a:"))
    async def admin_actions(c: CallbackQuery):
        if not admin(cfg, c.from_user.id):
            await c.answer("Нет доступа.", show_alert=True); return
        action = c.data.split(":")
        cmd = action[1]
        if cmd == "home":
            await c.message.edit_text("🔐 Панель администратора", reply_markup=admin_menu())
        elif cmd == "requests":
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,telegram_id,tariff_name,duration_days,price,created_at,email,subscription_no FROM subscription_requests WHERE status='pending' ORDER BY id DESC LIMIT 25")
                rows = await cur.fetchall()
            if not rows:
                await c.message.edit_text("Ожидающих заявок нет.", reply_markup=ik([[("⬅️ Админка", "a:home")]]))
            else:
                buttons = [[(f"#{r[0]} · №{r[7] or '?'} · {r[2]} · {r[4]} ₽ · {r[6] or 'без email'} · TG {r[1]}", f"a:req:{r[0]}")] for r in rows]
                buttons.append([("⬅️ Админка", "a:home")])
                await c.message.edit_text("Ожидающие заявки:", reply_markup=ik(buttons))
        elif cmd == "req":
            rid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,telegram_id,tariff_name,duration_days,price,device_limit,traffic_gb,status,created_at,email,subscription_no,telegram_username FROM subscription_requests WHERE id=?", (rid,))
                r = await cur.fetchone()
            if not r:
                await c.answer("Заявка не найдена.", show_alert=True); return
            await c.message.edit_text(f"Заявка #{r[0]} · подписка №{r[10] or '?'}\nTelegram ID: {r[1]} (@{r[11] or 'без username'})\nEmail: {r[9] or 'не указан'}\nТариф: {r[2]}\nСрок: {r[3]} дней\nЦена: {r[4]} ₽\nУстройств: {r[5]}\nТрафик: {'без лимита' if not r[6] else str(r[6])+' ГБ'}\nСтатус: {r[7]}",
                reply_markup=ik([[("✅ Одобрить и выдать", f"a:approve:{rid}"), ("❌ Отклонить", f"a:reject:{rid}")], [("⬅️ К заявкам", "a:requests")]]))
        elif cmd in ("approve", "reject"):
            rid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT telegram_id,tariff_name,duration_days,price,device_limit,traffic_gb,status,server_targets FROM subscription_requests WHERE id=?", (rid,))
                r = await cur.fetchone()
            if not r or r[6] != "pending":
                await c.answer("Заявка уже обработана или не найдена.", show_alert=True); return
            if cmd == "reject":
                async with aiosqlite.connect(path) as db:
                    await db.execute("UPDATE subscription_requests SET status='rejected',reviewed_by=?,reviewed_at=CURRENT_TIMESTAMP WHERE id=?", (c.from_user.id,rid))
                    await db.commit()
                await c.message.edit_text(f"Заявка #{rid} отклонена.")
                try: await bot.send_message(r[0], f"Заявка #{rid} отклонена. Если это ошибка, обратитесь в поддержку.")
                except Exception: pass
            else:
                try:
                    result = await provision_request(rid, reviewed_by=c.from_user.id)
                    await c.message.edit_text(
                        f"Заявка #{rid} одобрена. Клиент создан на {result['servers']} сервер(ах).\nНомер подписки: {result['number']}.",
                        reply_markup=ik([[ ("⬅️ К заявкам", "a:requests") ]])
                    )
                except (XUIError, KeyError, ValueError, TypeError) as e:
                    await c.message.edit_text(
                        f"Не удалось создать VPN-подписку: {e}. Заявка оставлена ожидающей.",
                        reply_markup=ik([[ ("⬅️ К заявке", f"a:req:{rid}") ]])
                    )
        elif cmd in ("approvepanel", "approveinbound"):
            # Compatibility with old inline buttons: approval always follows tariff targets
            # and never asks the administrator to select a server again.
            rid = int(action[2])
            try:
                result = await provision_request(rid, reviewed_by=c.from_user.id)
                await c.message.edit_text(
                    f"Заявка #{rid} одобрена. Клиент создан на {result['servers']} сервер(ах).\nНомер подписки: {result['number']}.",
                    reply_markup=ik([[ ("⬅️ К заявкам", "a:requests") ]])
                )
            except (XUIError, KeyError, ValueError, TypeError) as e:
                await c.message.edit_text(
                    f"Не удалось создать VPN-подписку: {e}. Заявка оставлена ожидающей.",
                    reply_markup=ik([[ ("⬅️ К заявке", f"a:req:{rid}") ]])
                )
        elif cmd == "tgproxy":
            enabled = await setting(path, "tgproxy_enabled", "1") == "1"
            pid = await setting(path, "tgproxy_panel_id", "")
            iid = await setting(path, "tgproxy_inbound_id", "")
            host = await setting(path, "tgproxy_host", "")
            rows = [[(f"{'🟢 Включён' if enabled else '⚪ Выключен'} — переключить", "a:tgproxytoggle")]
            ]
            for panel in cfg.get("panels", []):
                if not panel.get("enabled"): continue
                try:
                    for inbound in await panel_obj(panel).list_inbounds():
                        if str(inbound.get("protocol", "")).lower() != "mtproto": continue
                        selected = str(panel.get("id")) == pid and str(inbound.get("id")) == iid
                        rows.append([(f"{'✅' if selected else '⬜'} {panel.get('name')} · #{inbound.get('id')} · {inbound.get('remark') or 'MTProto'} · порт {inbound.get('port')}", f"a:tgproxyselect:{panel.get('id')}:{inbound.get('id')}")])
                except XUIError as e:
                    log.warning("Не удалось загрузить MTProto inbounds панели %s: %s", panel.get("id"), e)
            rows.extend([[ ("ℹ️ Указать публичный адрес", "a:tgproxyhosthelp")], [ ("⬅️ Админка", "a:home")]])
            await c.message.edit_text(f"📡 Настройка Telegram Proxy\nСтатус: {'включён' if enabled else 'выключен'}\nВыбрано: {pid or '—'} / inbound #{iid or '—'}\nПубличный адрес: {host or 'автоматически из адреса панели / shareAddr'}\n\nВыберите MTProto inbound. Для адреса используйте /tgproxyhost example.com.", reply_markup=ik(rows))
        elif cmd == "tgproxytoggle":
            value = "0" if await setting(path, "tgproxy_enabled", "1") == "1" else "1"
            await set_setting(path, "tgproxy_enabled", value)
            await c.message.edit_text(f"Telegram Proxy {'включён' if value == '1' else 'выключен'}.", reply_markup=ik([[ ("⚙️ Настройки Telegram Proxy", "a:tgproxy")], [ ("⬅️ Админка", "a:home")]]))
        elif cmd == "tgproxyselect":
            pid, inbound_id = action[2], int(action[3])
            panel = panel_cfg(cfg, pid)
            if not panel:
                await c.answer("Панель не найдена.", show_alert=True); return
            inbounds = await panel_obj(panel).list_inbounds()
            inbound = next((item for item in inbounds if int(item.get("id") or 0) == inbound_id), None)
            if not inbound or str(inbound.get("protocol", "")).lower() != "mtproto":
                await c.answer("Выбранный inbound не является MTProto.", show_alert=True); return
            await set_setting(path, "tgproxy_panel_id", pid)
            await set_setting(path, "tgproxy_inbound_id", str(inbound_id))
            # Existing user records belong to the previous server; do not silently rewrite their links.
            await c.message.edit_text(f"Сервер Telegram Proxy выбран: {panel.get('name')} · {inbound.get('remark') or 'MTProto'} · порт {inbound.get('port')}.\nЕсли это другой сервер, новые подключения пойдут на него; уже выданные ссылки останутся прежними.", reply_markup=ik([[ ("⬅️ Настройки Telegram Proxy", "a:tgproxy")]]))
        elif cmd == "tgproxyhosthelp":
            await c.message.edit_text("Укажите публичный IP или домен MTProto-сервера командой:\n/tgproxyhost example.com\n\nЭто адрес, на который будут направлены персональные ссылки. Не указывайте https:// и порт.", reply_markup=ik([[ ("⬅️ Настройки Telegram Proxy", "a:tgproxy")]]))
        elif cmd == "panels":
            rows = [[(f"{'🟢' if p.get('enabled') else '⚪'} {p.get('name',p.get('id'))}", f"a:panel:{p.get('id')}")] for p in cfg.get("panels", [])]
            rows.append([("⬅️ Админка", "a:home")])
            await c.message.edit_text("Панели 3x-ui из config.yml:", reply_markup=ik(rows))
        elif cmd == "panel":
            pid = action[2]
            p = panel_cfg(cfg, pid)
            if not p:
                await c.answer("Панель не найдена.", show_alert=True); return
            try:
                result = await panel_obj(p).test_connection()
                clients = await panel_obj(p).list_clients()
                msg = f"✅ {p.get('name')}\n{result}\nНайдено клиентов: {len(clients)}\nAPI доступен для управления клиентами."
            except XUIError as e:
                msg = f"❌ Ошибка панели: {e}"
            await c.message.edit_text(msg, reply_markup=ik([[("⬅️ К серверам", "a:panels")]]))
        elif cmd == "subs":
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,telegram_id,panel_id,email,tariff_name,expiry_at,status,subscription_no,subscription_group FROM subscriptions ORDER BY id DESC LIMIT 100")
                rows = await cur.fetchall()
            if not rows:
                # Show actual clients from panels, with bind controls.
                found = []
                for p in cfg.get("panels", []):
                    if not p.get("enabled"): continue
                    try:
                        for cl in await panel_obj(p).list_clients():
                            found.append((p, cl))
                    except XUIError:
                        continue
                buttons = []
                for p, cl in found[:30]:
                    email = str(cl.get("email") or cl.get("id") or "client")
                    buttons.append([(f"{p.get('name')} · {email}", f"a:client:{p['id']}:{cl.get('_inbound_id')}:{cl.get('id')}")])
                buttons.append([("⬅️ Админка", "a:home")])
                await c.message.edit_text("Привязанные записи отсутствуют. Клиенты, найденные в 3x-ui (нажмите для привязки):" if found else "Записей нет; подключённые панели не вернули клиентов.", reply_markup=ik(buttons))
            else:
                buttons = []
                seen_groups = set()
                for r in rows:
                    group_key = r[8] or f"legacy-{r[0]}"
                    if group_key in seen_groups:
                        continue
                    seen_groups.add(group_key)
                    number_text = f"№{r[7]}" if r[7] else f"#{r[0]}"
                    buttons.append([(f"{number_text} · {r[3] or 'клиент'} · TG {r[1] or 'не привязан'}", f"a:sub:{r[0]}")])
                buttons.append([("🔎 Найти клиентов в 3x-ui", "a:discover")])
                buttons.append([("⬅️ Админка", "a:home")])
                await c.message.edit_text("Подписки в базе:", reply_markup=ik(buttons))
        elif cmd == "sub":
            sid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,telegram_id,panel_id,inbound_id,client_uuid,email,tariff_name,expiry_at,status FROM subscriptions WHERE id=?", (sid,))
                r = await cur.fetchone()
            if not r:
                await c.answer("Подписка не найдена.", show_alert=True); return
            expiry_text = datetime.fromtimestamp(r[7], timezone.utc).strftime("%d.%m.%Y %H:%M UTC") if r[7] else "не указан"
            await c.message.edit_text(
                f"Подписка #{r[0]}\nTelegram ID: {r[1] or 'не привязан'}\nСервер: {r[2]} / inbound {r[3]}\nКлиент: {r[5] or r[4]}\nТариф: {r[6] or 'не указан'}\nОкончание: {expiry_text}\nСтатус: {r[8]}",
                reply_markup=ik([[ ("➕ Добавить сервер", f"a:addserver:{sid}") ], [ ("🗑 Удалить подписку и клиента", f"a:deletesub:{sid}") ], [ ("⬅️ К подпискам", "a:subs") ]])
            )
        elif cmd == "deletesub":
            sid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT subscription_group,subscription_no,telegram_id FROM subscriptions WHERE id=?", (sid,))
                base_row = await cur.fetchone()
                if base_row and base_row[0]:
                    cur = await db.execute("SELECT id,panel_id,inbound_id,client_uuid,email FROM subscriptions WHERE subscription_group=?", (base_row[0],))
                elif base_row:
                    cur = await db.execute("SELECT id,panel_id,inbound_id,client_uuid,email FROM subscriptions WHERE id=?", (sid,))
                else:
                    cur = None
                entries = await cur.fetchall() if cur else []
            if not entries:
                await c.answer("Подписка не найдена.", show_alert=True); return
            try:
                for entry_id, pid, inbound_id, client_uuid, email in entries:
                    panel = panel_cfg(cfg, str(pid))
                    if panel and client_uuid and inbound_id:
                        await panel_obj(panel).delete_client(int(inbound_id), str(client_uuid), str(email or ""), whole_client=False)
                    elif client_uuid and inbound_id:
                        raise XUIError(f"Панель {pid} отсутствует в config.yml; нельзя подтвердить удаление клиента.")
                async with aiosqlite.connect(path) as db:
                    if base_row[0]:
                        await db.execute("DELETE FROM subscriptions WHERE subscription_group=?", (base_row[0],))
                    else:
                        await db.execute("DELETE FROM subscriptions WHERE id=?", (sid,))
                    await db.commit()
                num_text = f"№{base_row[1]}" if base_row[1] else f"#{sid}"
                await c.message.edit_text(f"Подписка {num_text} полностью удалена: записи всех серверов удалены из базы и обработаны через API 3x-ui.", reply_markup=ik([[ ("⬅️ К подпискам", "a:subs") ]]))
            except XUIError as e:
                await c.message.edit_text(f"Не удалось полностью удалить подписку из 3x-ui. Записи в базе сохранены для проверки. Ошибка: {e}", reply_markup=ik([[ ("⬅️ К подписке", f"a:sub:{sid}") ]]))
        elif cmd == "addserver":
            sid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,telegram_id,email,tariff_name,expiry_at,device_limit,traffic_gb FROM subscriptions WHERE id=?", (sid,))
                sub = await cur.fetchone()
            if not sub:
                await c.answer("Подписка не найдена.", show_alert=True); return
            await set_setting(path, f"addserver_pending:{c.from_user.id}", json.dumps({"subscription_id":sid,"telegram_id":sub[1],"email":sub[2],"tariff_name":sub[3],"expiry_at":sub[4],"device_limit":sub[5],"traffic_gb":sub[6]}))
            rows = []
            for panel in cfg.get("panels", []):
                if not panel.get("enabled"): continue
                try:
                    inbounds = await panel_obj(panel).list_inbounds()
                    for inbound in inbounds:
                        rows.append([(f"{panel.get('name')} · inbound #{inbound.get('id')} · {inbound.get('remark') or inbound.get('protocol') or ''}", f"a:addtarget:{sid}:{panel.get('id')}:{inbound.get('id')}")])
                except XUIError as e:
                    log.warning("Не удалось получить inbound для %s: %s", panel.get("id"), e)
            rows.append([("⬅️ К подписке", f"a:sub:{sid}")])
            await c.message.edit_text("Выберите сервер/inbound, на который добавить этого клиента:", reply_markup=ik(rows))
        elif cmd == "addtarget":
            sid, pid, inbound_id = int(action[2]), action[3], int(action[4])
            raw = await setting(path, f"addserver_pending:{c.from_user.id}", "")
            if not raw:
                await c.answer("Сценарий истёк, откройте подписку заново.", show_alert=True); return
            data = json.loads(raw)
            panel = panel_cfg(cfg, pid)
            try:
                if not panel: raise XUIError("Сервер не найден в config.yml.")
                expiry = float(data.get("expiry_at") or 0)
                days = max(1, int((expiry - time.time()) / 86400)) if expiry else 30
                base_email = str(data.get("email") or f"tg{data.get('telegram_id')}")
                target_email = f"{base_email[:42]}_i{inbound_id}"
                result = await panel_obj(panel).add_client(int(inbound_id), email=target_email, total_gb=int(data.get("traffic_gb") or 0), duration_days=days, max_ips=int(data.get("device_limit") or 1))
                cl = result["client"]
                async with aiosqlite.connect(path) as db:
                    await db.execute("""INSERT OR IGNORE INTO subscriptions(telegram_id,panel_id,inbound_id,client_uuid,email,client_json,sub_url,tariff_name,start_at,expiry_at,device_limit,traffic_gb,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?, 'active')""", (data.get("telegram_id"),pid,int(inbound_id),cl["id"],target_email,json.dumps(cl),await setting(path,"default_subscription_url",""),data.get("tariff_name"),int(time.time()),cl["expiryTime"]/1000,data.get("device_limit") or 1,data.get("traffic_gb") or 0))
                    await db.commit()
                await set_setting(path, f"addserver_pending:{c.from_user.id}", "")
                await c.message.edit_text(f"Клиент добавлен на сервер {panel.get('name')} (inbound #{inbound_id}).", reply_markup=ik([[ ("⬅️ К подпискам", "a:subs") ]]))
            except XUIError as e:
                await c.message.edit_text(f"Не удалось добавить сервер: {e}", reply_markup=ik([[ ("⬅️ К подписке", f"a:sub:{sid}") ]]))
        elif cmd == "discover":
            found = []
            for p in cfg.get("panels", []):
                if not p.get("enabled"): continue
                try:
                    for cl in await panel_obj(p).list_clients():
                        found.append((p, cl))
                except XUIError as e:
                    log.warning("Панель %s: %s", p.get("id"), e)
            buttons = [[(f"{p.get('name')} · {cl.get('email') or cl.get('id')}", f"a:client:{p['id']}:{cl.get('_inbound_id')}:{cl.get('id')}")] for p, cl in found[:40]]
            buttons.append([("⬅️ Подписки", "a:subs")])
            await c.message.edit_text(f"Клиенты в 3x-ui: {len(found)}. Выберите клиента, чтобы привязать Telegram.", reply_markup=ik(buttons))
        elif cmd == "client":
            pid, inbound_id, client_id = action[2], int(action[3]), action[4]
            p = panel_cfg(cfg, pid)
            try:
                clients = await panel_obj(p).list_clients() if p else []
                cl = next((x for x in clients if str(x.get("_inbound_id")) == str(inbound_id) and str(x.get("id")) == client_id), None)
                if not cl: raise XUIError("Клиент не найден.")
                expiry = int(cl.get("expiryTime") or 0)
                expiry_text = datetime.fromtimestamp(expiry / 1000, timezone.utc).strftime("%d.%m.%Y %H:%M UTC") if expiry else "не указан"
                msg = f"Клиент: {cl.get('email') or 'без email'}\nUUID: {client_id}\nInbound: {inbound_id}\nОкончание: {expiry_text}\nЛимит устройств: {cl.get('limitIp', 1)}\n\nВыберите действие:"
            except XUIError as e:
                msg = f"Ошибка чтения клиента: {e}"
            await c.message.edit_text(msg, reply_markup=ik([[ ("🔗 Привязать Telegram", f"a:bind:{pid}:{inbound_id}:{client_id}")], [("♻️ Сбросить трафик", f"a:reset:{pid}:{inbound_id}:{client_id}")], [("➕ Продлить на 30 дней", f"a:extend:{pid}:{inbound_id}:{client_id}:30")], [("➕ Продлить на 90 дней", f"a:extend:{pid}:{inbound_id}:{client_id}:90")], [("⬅️ К клиентам", "a:discover")]]))
        elif cmd == "bind":
            pid, inbound_id, client_id = action[2], int(action[3]), action[4]
            await set_setting(path, f"bind_pending:{c.from_user.id}", json.dumps({"panel_id":pid,"inbound_id":inbound_id,"client_id":client_id}))
            await c.message.edit_text("Отправьте числовой Telegram ID пользователя для привязки. Для отмены: /cancel", reply_markup=ik([[ ("⬅️ Отмена", "a:subs")]]))
        elif cmd == "reset":
            pid, inbound_id, client_id = action[2], int(action[3]), action[4]
            p = panel_cfg(cfg, pid)
            try:
                clients = await panel_obj(p).list_clients() if p else []
                cl = next((x for x in clients if str(x.get("_inbound_id")) == str(inbound_id) and str(x.get("id")) == client_id), None)
                if not cl: raise XUIError("Клиент не найден.")
                await panel_obj(p).reset_client_traffic(inbound_id, str(cl.get("email", "")))
                await c.message.edit_text(f"Трафик клиента {cl.get('email')} сброшен.", reply_markup=ik([[ ("⬅️ К клиенту", f"a:client:{pid}:{inbound_id}:{client_id}")]]))
            except XUIError as e:
                await c.message.edit_text(f"Не удалось сбросить трафик: {e}", reply_markup=ik([[ ("⬅️ К клиентам", "a:discover")]]))
        elif cmd == "extend":
            pid, inbound_id, client_id, days = action[2], int(action[3]), action[4], int(action[5])
            p = panel_cfg(cfg, pid)
            try:
                result = await panel_obj(p).extend_client(inbound_id, client_id, days) if p else None
                cl = result["client"]
                async with aiosqlite.connect(path) as db:
                    await db.execute("UPDATE subscriptions SET expiry_at=?,client_json=? WHERE panel_id=? AND inbound_id=? AND client_uuid=?", (int(cl.get("expiryTime",0))/1000, json.dumps(cl), pid, inbound_id, client_id))
                    await db.commit()
                await c.message.edit_text(f"Срок клиента продлён на {days} дней.", reply_markup=ik([[ ("⬅️ К клиенту", f"a:client:{pid}:{inbound_id}:{client_id}")]]))
            except XUIError as e:
                await c.message.edit_text(f"Не удалось продлить клиента: {e}", reply_markup=ik([[ ("⬅️ К клиентам", "a:discover")]]))
        elif cmd == "create":
            rows = [[(str(p.get("name", p.get("id"))), f"a:createpanel:{p.get('id')}")] for p in cfg.get("panels", []) if p.get("enabled")]
            rows.append([("⬅️ Админка", "a:home")])
            await c.message.edit_text("Выберите панель для создания VPN-клиента:", reply_markup=ik(rows))
        elif cmd == "createpanel":
            pid = action[2]
            p = panel_cfg(cfg, pid)
            if not p or not p.get("enabled"):
                await c.answer("Панель отключена или не найдена.", show_alert=True); return
            try:
                inbounds = await panel_obj(p).list_inbounds()
                rows = [[(f"Inbound #{i.get('id')} · {i.get('remark') or i.get('protocol') or 'без названия'}", f"a:createinbound:{pid}:{i.get('id')}")] for i in inbounds]
                rows.append([("⬅️ Назад", "a:create")])
                await c.message.edit_text("Выберите inbound для нового клиента:", reply_markup=ik(rows))
            except XUIError as e:
                await c.message.edit_text(f"Ошибка панели: {e}", reply_markup=ik([[ ("⬅️ Назад", "a:create")]]))
        elif cmd == "createinbound":
            pid, inbound_id = action[2], int(action[3])
            await set_setting(path, f"create_pending:{c.from_user.id}", json.dumps({"panel_id":pid,"inbound_id":inbound_id}))
            await c.message.edit_text("Отправьте одной строкой: email | срок_дней | лимит_устройств | лимит_трафика_ГБ | Telegram_ID_или_0\nПример: user123 | 30 | 2 | 100 | 123456789\nТрафик 0 означает без лимита.", reply_markup=ik([[ ("⬅️ Отмена", "a:create")]]))
        elif cmd == "own":
            await c.message.edit_text("Управление подпиской администратора работает через тот же раздел «Подписки»: найдите или привяжите свой клиент 3x-ui к собственному Telegram ID.", reply_markup=ik([[("📦 Подписки", "a:subs")], [("⬅️ Админка", "a:home")]]))
        elif cmd == "tariffs":
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT id,name,duration_days,price,device_limit,traffic_gb,enabled,server_targets FROM tariffs ORDER BY id")
                rows = await cur.fetchall()
            buttons = []
            for r in rows:
                try: nservers = len(json.loads(r[7] or "[]"))
                except Exception: nservers = 0
                buttons.append([(f"#{r[0]} {r[1]} · {r[2]} дн. · {r[3]} ₽ · серверов: {nservers} · {'вкл' if r[6] else 'выкл'}", f"a:tariff:{r[0]}")])
            buttons.extend([[ ("➕ Добавить тариф", "a:addtariff") ], [ ("⬅️ Админка", "a:home") ]])
            await c.message.edit_text("Тарифы: откройте тариф, чтобы настроить серверы, включение и удаление.", reply_markup=ik(buttons))
        elif cmd == "tariff":
            tid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT enabled,name,duration_days,price,device_limit,traffic_gb,server_targets FROM tariffs WHERE id=?", (tid,))
                r = await cur.fetchone()
            if not r:
                await c.answer("Тариф не найден.", show_alert=True); return
            try: targets = json.loads(r[6] or "[]")
            except Exception: targets = []
            target_text = "\n".join(f"• {t.get('panel_id')} / inbound #{t.get('inbound_id')}" for t in targets) or "• не выбраны"
            await c.message.edit_text(f"Тариф «{r[1]}»\nСрок: {r[2]} дней · Цена: {r[3]} ₽\nУстройств: {r[4]} · Трафик: {'без лимита' if not r[5] else str(r[5])+' ГБ'}\nСтатус: {'включён' if r[0] else 'выключен'}\nСерверы для выдачи:\n{target_text}", reply_markup=ik([[ ("🖥 Настроить серверы", f"a:tariffservers:{tid}") ], [ ("🔁 Включить / выключить", f"a:tarifftoggle:{tid}") ], [ ("🗑 Удалить тариф", f"a:deletetariff:{tid}") ], [ ("⬅️ К тарифам", "a:tariffs") ]]))
        elif cmd == "tarifftoggle":
            tid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT enabled,name FROM tariffs WHERE id=?", (tid,)); r = await cur.fetchone()
                if r:
                    await db.execute("UPDATE tariffs SET enabled=? WHERE id=?", (0 if r[0] else 1, tid)); await db.commit()
            await c.message.edit_text(f"Тариф «{r[1]}» теперь {'выключен' if r[0] else 'включён'}." if r else "Тариф не найден.", reply_markup=ik([[ ("⬅️ К тарифу", f"a:tariff:{tid}") ]]))
        elif cmd == "deletetariff":
            tid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT name FROM tariffs WHERE id=?", (tid,)); r = await cur.fetchone()
                if r:
                    await db.execute("DELETE FROM tariffs WHERE id=?", (tid,)); await db.commit()
            await c.message.edit_text(f"Тариф «{r[0]}» полностью удалён." if r else "Тариф не найден.", reply_markup=ik([[ ("⬅️ К тарифам", "a:tariffs") ]]))
        elif cmd == "tariffservers":
            tid = int(action[2])
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT server_targets FROM tariffs WHERE id=?", (tid,)); row = await cur.fetchone()
            if not row:
                await c.answer("Тариф не найден.", show_alert=True); return
            await set_setting(path, f"tariff_targets:{c.from_user.id}", json.dumps({"tariff_id":tid,"targets":json.loads(row[0] or "[]")}))
            rows = []
            selected = {(str(t.get("panel_id")), int(t.get("inbound_id"))) for t in json.loads(row[0] or "[]")}
            for panel in cfg.get("panels", []):
                if not panel.get("enabled"): continue
                try:
                    for inbound in await panel_obj(panel).list_inbounds():
                        pair = (str(panel.get("id")), int(inbound.get("id")))
                        mark = "✅" if pair in selected else "⬜"
                        label = f"{mark} {panel.get('name')} · #{inbound.get('id')} · {inbound.get('remark') or inbound.get('protocol') or 'inbound'}"
                        rows.append([(label, f"a:ttoggle:{tid}:{panel.get('id')}:{inbound.get('id')}")])
                except XUIError as e:
                    log.warning("Тариф: не удалось загрузить inbound для %s: %s", panel.get("id"), e)
            rows.extend([[ ("💾 Сохранить серверы", f"a:tsave:{tid}") ], [ ("⬅️ К тарифу", f"a:tariff:{tid}") ]])
            await c.message.edit_text("Отметьте все серверы/inbound, на которых нужно создавать клиента. Можно выбрать несколько.", reply_markup=ik(rows))
        elif cmd == "ttoggle":
            tid, pid, inbound_id = int(action[2]), action[3], int(action[4])
            raw = await setting(path, f"tariff_targets:{c.from_user.id}", "")
            data = json.loads(raw) if raw else {"tariff_id":tid,"targets":[]}
            targets = data.setdefault("targets", [])
            existing = next((t for t in targets if str(t.get("panel_id")) == pid and int(t.get("inbound_id")) == inbound_id), None)
            if existing: targets.remove(existing)
            else: targets.append({"panel_id":pid,"inbound_id":inbound_id})
            await set_setting(path, f"tariff_targets:{c.from_user.id}", json.dumps(data))
            rows = []
            selected = {(str(t.get("panel_id")), int(t.get("inbound_id"))) for t in targets}
            for panel in cfg.get("panels", []):
                if not panel.get("enabled"): continue
                try:
                    for inbound in await panel_obj(panel).list_inbounds():
                        pair=(str(panel.get("id")),int(inbound.get("id"))); mark="✅" if pair in selected else "⬜"
                        rows.append([(f"{mark} {panel.get('name')} · #{inbound.get('id')} · {inbound.get('remark') or inbound.get('protocol') or 'inbound'}", f"a:ttoggle:{tid}:{panel.get('id')}:{inbound.get('id')}")])
                except XUIError: pass
            rows.extend([[ ("💾 Сохранить серверы", f"a:tsave:{tid}") ], [ ("⬅️ К тарифу", f"a:tariff:{tid}") ]])
            await c.message.edit_text("Отметьте все серверы/inbound, на которых нужно создавать клиента. Можно выбрать несколько.", reply_markup=ik(rows))
        elif cmd == "tsave":
            tid = int(action[2]); raw = await setting(path, f"tariff_targets:{c.from_user.id}", "")
            data = json.loads(raw) if raw else {"targets":[]}
            targets = data.get("targets", [])
            async with aiosqlite.connect(path) as db:
                await db.execute("UPDATE tariffs SET server_targets=? WHERE id=?", (json.dumps(targets), tid)); await db.commit()
            await set_setting(path, f"tariff_targets:{c.from_user.id}", "")
            await c.message.edit_text(f"Серверы тарифа сохранены. Выбрано: {len(targets)}.", reply_markup=ik([[ ("⬅️ К тарифу", f"a:tariff:{tid}") ]]))
        elif cmd == "addtariff":
            await set_setting(path, f"wizard:{c.from_user.id}", "addtariff")
            await c.message.edit_text("Отправьте тариф одной строкой:\nНазвание | срок_в_днях | цена_в_рублях | лимит_устройств | трафик_ГБ\nПример: 1 месяц | 30 | 199 | 2 | 100\nПосле этого выберете серверы для тарифа. Трафик 0 = без лимита.", reply_markup=ik([[ ("⬅️ К тарифам", "a:tariffs") ]]))
        elif cmd == "settings":
            welcome = await setting(path, "welcome")
            support = await setting(path, "support")
            await c.message.edit_text(f"Текущее приветствие:\n{welcome}\n\nПоддержка: {support}\n\nДля изменения используйте команды:\n/setwelcome текст\n/setsupport @username", reply_markup=ik([[("⬅️ Админка", "a:home")]]))
        elif cmd == "stats":
            async with aiosqlite.connect(path) as db:
                users = (await (await db.execute("SELECT COUNT(*) FROM users")).fetchone())[0]
                subs = (await (await db.execute("SELECT COUNT(*) FROM subscriptions WHERE status='active'")).fetchone())[0]
                reqs = (await (await db.execute("SELECT COUNT(*) FROM subscription_requests WHERE status='pending'")).fetchone())[0]
            await c.message.edit_text(f"📊 Статистика\nПользователей: {users}\nПодписок в базе: {subs}\nОжидающих заявок: {reqs}", reply_markup=ik([[("⬅️ Админка", "a:home")]]))
        else:
            await c.answer("Неизвестный раздел.")

        await c.answer()

    @dp.message(Command("tgproxyhost"))
    async def set_tgproxy_host(message: Message):
        if not admin(cfg, message.from_user.id): return
        host = message.text.partition(" ")[2].strip().strip("/")
        if host.startswith(("http://", "https://")) or "/" in host or ":" in host:
            await message.answer("Укажите только публичный IP или домен без схемы и порта. Например: /tgproxyhost proxy.example.com")
            return
        if not host:
            await message.answer("Использование: /tgproxyhost proxy.example.com")
            return
        await set_setting(path, "tgproxy_host", host)
        await message.answer(f"Публичный адрес Telegram Proxy сохранён: {host}")

    @dp.message(Command("setwelcome"))
    async def setwelcome(message: Message):
        if not admin(cfg, message.from_user.id): return
        value = message.text.partition(" ")[2].strip()
        if not value:
            await message.answer("Использование: /setwelcome текст приветствия"); return
        await set_setting(path, "welcome", value)
        await message.answer("Приветствие сохранено.")

    @dp.message(Command("setsupport"))
    async def setsupport(message: Message):
        if not admin(cfg, message.from_user.id): return
        value = message.text.partition(" ")[2].strip()
        if not value:
            await message.answer("Использование: /setsupport @username"); return
        await set_setting(path, "support", value)
        await message.answer("Контакт поддержки сохранён.")

    @dp.message()
    async def admin_text_input(message: Message):
        if not message.text:
            return
        if message.text.strip().lower() == "/cancel":
            await set_setting(path, f"buy_pending:{message.from_user.id}", "")
            if admin(cfg, message.from_user.id):
                for key in (f"bind_pending:{message.from_user.id}", f"wizard:{message.from_user.id}", f"addserver_pending:{message.from_user.id}", f"tariff_targets:{message.from_user.id}", f"create_pending:{message.from_user.id}"):
                    await set_setting(path, key, "")
            await message.answer("Операция отменена.", reply_markup=user_menu() if not admin(cfg, message.from_user.id) else admin_menu())
            return
        buy_raw = await setting(path, f"buy_pending:{message.from_user.id}", "")
        if buy_raw:
            email = message.text.strip()
            if not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+", email):
                await message.answer("Введите корректный адрес электронной почты.")
                return
            tid = int(buy_raw)
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("SELECT name,duration_days,price,device_limit,traffic_gb,server_targets FROM tariffs WHERE id=? AND enabled=1", (tid,))
                tariff = await cur.fetchone()
            if not tariff:
                await set_setting(path, f"buy_pending:{message.from_user.id}", "")
                await message.answer("Тариф больше недоступен. Откройте меню покупки заново.", reply_markup=user_menu())
                return
            name, days, price, devices, traffic, targets = tariff
            if not json.loads(targets or "[]"):
                await message.answer("У этого тарифа не настроены серверы. Обратитесь к поддержке.")
                return
            number = await next_subscription_number(message.from_user.id)
            await save_user(path, message.from_user)
            async with aiosqlite.connect(path) as db:
                cur = await db.execute("""INSERT INTO subscription_requests
                    (telegram_id,tariff_id,tariff_name,duration_days,price,device_limit,traffic_gb,server_targets,email,telegram_username,subscription_no,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (message.from_user.id, tid, name, days, price, devices, traffic, targets, email,
                     message.from_user.username or "", number, "pending"))
                rid = cur.lastrowid
                await db.commit()
            await set_setting(path, f"buy_pending:{message.from_user.id}", "")
            if int(price) == 0:
                try:
                    result = await provision_request(rid)
                    await message.answer(f"Бесплатный тариф активирован автоматически. Ваша подписка №{result['number']}.", reply_markup=user_menu())
                except (XUIError, KeyError, ValueError, TypeError) as exc:
                    await message.answer("Не удалось активировать подписку из-за технической ошибки. Мы уведомили администратора. Пожалуйста, обратитесь в поддержку; повторно оформлять заявку не нужно.", reply_markup=user_menu())
                    for aid in cfg["admin"]["ids"]:
                        try:
                            await bot.send_message(aid, f"⚠️ Бесплатная заявка #{rid} не выдана автоматически. Пользователь TG {message.from_user.id}, email {email}. Ошибка: {exc}", reply_markup=ik([[ ("Обработать заявку", f"a:req:{rid}") ]]))
                        except Exception: pass
            else:
                for aid in cfg["admin"]["ids"]:
                    try:
                        await bot.send_message(aid, f"📥 Новая заявка #{rid}\nПользователь: {message.from_user.full_name} (ID {message.from_user.id}, @{message.from_user.username or 'без_username'})\nEmail: {email}\nПодписка №{number}\nТариф: {name}\nСрок: {days} дней\nЦена: {price} ₽\nУстройств: {devices}\nТрафик: {'без лимита' if not traffic else str(traffic)+' ГБ'}", reply_markup=ik([[ ("✅ Одобрить и выдать доступ", f"a:approve:{rid}"), ("❌ Отклонить", f"a:reject:{rid}")]]))
                    except Exception:
                        log.exception("Не удалось уведомить администратора %s", aid)
                await message.answer(f"Заявка #{rid} отправлена администратору. После одобрения вы получите одну ссылку подписки и QR-код.", reply_markup=user_menu())
            return
        if not admin(cfg, message.from_user.id):
            return
        wizard_key = f"wizard:{message.from_user.id}"
        wizard = await setting(path, wizard_key, "")
        if wizard == "addtariff":
            try:
                parts = [x.strip() for x in message.text.split("|")]
                if len(parts) != 5: raise ValueError
                name, days, price, devices, traffic = parts[0], int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4])
                if not name or days < 1 or price < 0 or devices < 1 or traffic < 0: raise ValueError
                async with aiosqlite.connect(path) as db:
                    cur = await db.execute("INSERT INTO tariffs(name,duration_days,price,device_limit,traffic_gb,server_targets) VALUES(?,?,?,?,?,'[]')", (name,days,price,devices,traffic))
                    tid = cur.lastrowid
                    await db.commit()
                await set_setting(path, wizard_key, "")
                await set_setting(path, f"tariff_targets:{message.from_user.id}", json.dumps({"tariff_id":tid,"targets":[]}))
                rows = []
                for panel in cfg.get("panels", []):
                    if not panel.get("enabled"): continue
                    try:
                        for inbound in await panel_obj(panel).list_inbounds():
                            rows.append([(f"⬜ {panel.get('name')} · #{inbound.get('id')} · {inbound.get('remark') or inbound.get('protocol') or 'inbound'}", f"a:ttoggle:{tid}:{panel.get('id')}:{inbound.get('id')}")])
                    except XUIError as e:
                        log.warning("Не удалось загрузить inbound для тарифа: %s", e)
                rows.extend([[ ("💾 Сохранить серверы", f"a:tsave:{tid}") ], [ ("Пропустить / вернуться", f"a:tariff:{tid}") ]])
                await message.answer(f"Тариф «{name}» создан. Теперь выберите серверы/inbound для выдачи клиентов:", reply_markup=ik(rows))
            except (ValueError, AttributeError):
                await message.answer("Не удалось разобрать формат. Отправьте: Название | дни | цена | устройства | ГБ")
            return
        create_raw = await setting(path, f"create_pending:{message.from_user.id}", "")
        if create_raw:
            try:
                parts = [x.strip() for x in message.text.split("|")]
                if len(parts) != 5: raise ValueError
                email, days, devices, traffic, tg = parts[0], int(parts[1]), int(parts[2]), int(parts[3]), int(parts[4])
                if not re.fullmatch(r"[A-Za-z0-9_.@+-]{1,64}", email) or days < 1 or devices < 1 or traffic < 0 or tg < 0: raise ValueError
                data = json.loads(create_raw)
                p = panel_cfg(cfg, data["panel_id"])
                if not p: raise XUIError("Панель не найдена в config.yml.")
                result = await panel_obj(p).add_client(int(data["inbound_id"]), email=email, total_gb=traffic, duration_days=days, max_ips=devices)
                cl = result["client"]
                now = int(time.time())
                async with aiosqlite.connect(path) as db:
                    await db.execute("""INSERT OR REPLACE INTO subscriptions(telegram_id,panel_id,inbound_id,client_uuid,email,client_json,tariff_name,start_at,expiry_at,device_limit,traffic_gb,status)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,'active')""", (tg or None, data["panel_id"], int(data["inbound_id"]), cl["id"], email, json.dumps(cl), "Создана администратором", now, cl["expiryTime"]/1000, devices, traffic))
                    await db.commit()
                await set_setting(path, f"create_pending:{message.from_user.id}", "")
                await message.answer(f"Клиент {email} создан в 3x-ui. UUID: {cl['id']}\nСрок: {days} дней.\nTelegram: {tg if tg else 'не привязан'}")
                if tg:
                    try: await bot.send_message(tg, "Администратор создал для вас VPN-подписку. Откройте «Мои подписки».")
                    except Exception: pass
            except (ValueError, XUIError) as e:
                await message.answer(f"Не удалось создать клиента: {e or 'неверный формат'}. Повторите формат или отправьте /cancel.")
            return
        bind_raw = await setting(path, f"bind_pending:{message.from_user.id}", "")
        if bind_raw:
            if not message.text.strip().isdigit():
                await message.answer("Нужен числовой Telegram ID. Для отмены используйте /cancel."); return
            data = json.loads(bind_raw)
            target_id = int(message.text.strip())
            pid = data["panel_id"]
            p = panel_cfg(cfg, pid)
            if not p:
                await message.answer("Панель из конфигурации не найдена."); return
            try:
                clients = await panel_obj(p).list_clients()
                cl = next((x for x in clients if str(x.get("_inbound_id")) == str(data["inbound_id"]) and str(x.get("id")) == str(data["client_id"])), None)
                if not cl:
                    await message.answer("Клиент больше не найден в панели."); return
                async with aiosqlite.connect(path) as db:
                    await db.execute("""INSERT INTO subscriptions
                        (telegram_id,panel_id,inbound_id,client_uuid,email,client_json,tariff_name,start_at,expiry_at,device_limit,traffic_gb,status)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,'active')
                        ON CONFLICT(panel_id,inbound_id,client_uuid) DO UPDATE SET telegram_id=excluded.telegram_id,email=excluded.email,client_json=excluded.client_json,status='active'""",
                        (target_id,pid,int(data["inbound_id"]),str(data["client_id"]),str(cl.get("email","")),json.dumps(cl),str(cl.get("email","")),int(time.time()),int(cl.get("expiryTime",0))/1000 if cl.get("expiryTime") else None,int(cl.get("limitIp",1)),int(cl.get("totalGB",0)/1024**3) if cl.get("totalGB") else 0))
                    await db.commit()
                await set_setting(path, f"bind_pending:{message.from_user.id}", "")
                await message.answer(f"Клиент {cl.get('email') or data['client_id']} привязан к Telegram ID {target_id}.")
                try: await bot.send_message(target_id, "Ваша VPN-подписка привязана. Откройте «Мои подписки».")
                except Exception: pass
            except XUIError as e:
                await message.answer(f"Ошибка 3x-ui: {e}")
            return
        await message.answer("Команда не распознана. Используйте кнопки меню или /admin.")

    @dp.message(Command("cancel"))
    async def cancel(message: Message):
        if not admin(cfg, message.from_user.id): return
        await set_setting(path, f"bind_pending:{message.from_user.id}", "")
        await set_setting(path, f"wizard:{message.from_user.id}", "")
        await set_setting(path, f"addserver_pending:{message.from_user.id}", "")
        await set_setting(path, f"tariff_targets:{message.from_user.id}", "")
        await message.answer("Операция отменена.")

    log.info("Бот запускается; существующие клиенты 3x-ui не меняются при старте.")
    try:
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
